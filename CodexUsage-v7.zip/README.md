# Codex 用量任务栏小窗

Windows 任务栏上以透明背景显示 Codex 5 小时与每周窗口的剩余额度。5 小时窗口显示本地时间的下次重置时刻，周窗口显示下次重置日期。

## 启动

需要已安装并登录的 Codex CLI。双击 `start.bat` 启动。

首次使用或更新后，在 PowerShell 中运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

程序通过本机 `codex app-server` 读取用量，复用已登录的 Codex CLI，不会保存登录令牌。任务栏小窗左键立即刷新，右键菜单可刷新或退出。用量每分钟自动刷新；悬停可查看服务端返回的完整本地重置时间。
